/*
  # ScribeFlow AI Database Schema

  1. New Tables
    - `patients`
      - `id` (uuid, primary key)
      - `name` (text) - Patient full name
      - `medical_record_number` (text, unique) - MRN
      - `date_of_birth` (date) - Patient DOB
      - `created_at` (timestamptz) - Record creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp
    
    - `consultations`
      - `id` (uuid, primary key)
      - `patient_id` (uuid, foreign key to patients)
      - `physician_name` (text) - Name of physician
      - `consultation_date` (timestamptz) - When consultation occurred
      - `duration_minutes` (integer) - Duration in minutes
      - `transcript` (text) - Full transcript of conversation
      - `status` (text) - Status: recording, completed, reviewed
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `soap_notes`
      - `id` (uuid, primary key)
      - `consultation_id` (uuid, foreign key to consultations)
      - `subjective` (text) - Patient's description of symptoms
      - `objective` (text) - Observable findings
      - `assessment` (text) - Diagnosis and clinical impression
      - `plan` (text) - Treatment plan
      - `chief_complaint` (text) - Primary complaint
      - `medications` (jsonb) - List of medications
      - `follow_up_date` (date) - Next appointment date
      - `fhir_data` (jsonb) - FHIR-compatible JSON structure
      - `reviewed_by_physician` (boolean) - Whether physician reviewed
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their data
    
  3. Important Notes
    - This schema follows HIPAA-style data organization
    - All timestamps use timestamptz for timezone awareness
    - JSONB fields for flexible medication and FHIR data storage
    - Physician review tracking for compliance
*/

-- Create patients table
CREATE TABLE IF NOT EXISTS patients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  medical_record_number text UNIQUE NOT NULL,
  date_of_birth date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create consultations table
CREATE TABLE IF NOT EXISTS consultations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid REFERENCES patients(id) ON DELETE CASCADE,
  physician_name text NOT NULL,
  consultation_date timestamptz DEFAULT now(),
  duration_minutes integer DEFAULT 0,
  transcript text DEFAULT '',
  status text DEFAULT 'recording',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create soap_notes table
CREATE TABLE IF NOT EXISTS soap_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  consultation_id uuid REFERENCES consultations(id) ON DELETE CASCADE,
  subjective text DEFAULT '',
  objective text DEFAULT '',
  assessment text DEFAULT '',
  plan text DEFAULT '',
  chief_complaint text DEFAULT '',
  medications jsonb DEFAULT '[]'::jsonb,
  follow_up_date date,
  fhir_data jsonb DEFAULT '{}'::jsonb,
  reviewed_by_physician boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE consultations ENABLE ROW LEVEL SECURITY;
ALTER TABLE soap_notes ENABLE ROW LEVEL SECURITY;

-- Policies for patients table
CREATE POLICY "Users can view all patients"
  ON patients FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert patients"
  ON patients FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update patients"
  ON patients FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for consultations table
CREATE POLICY "Users can view all consultations"
  ON consultations FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert consultations"
  ON consultations FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update consultations"
  ON consultations FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Policies for soap_notes table
CREATE POLICY "Users can view all soap notes"
  ON soap_notes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert soap notes"
  ON soap_notes FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update soap notes"
  ON soap_notes FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_consultations_patient_id ON consultations(patient_id);
CREATE INDEX IF NOT EXISTS idx_consultations_date ON consultations(consultation_date);
CREATE INDEX IF NOT EXISTS idx_soap_notes_consultation_id ON soap_notes(consultation_id);
CREATE INDEX IF NOT EXISTS idx_patients_mrn ON patients(medical_record_number);