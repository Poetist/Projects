import { useState } from 'react';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import RecordingInterface from './components/RecordingInterface';

type AppView = 'landing' | 'dashboard' | 'recording';

function App() {
  const [currentView, setCurrentView] = useState<AppView>('landing');

  const handleGetStarted = () => {
    setCurrentView('dashboard');
  };

  const handleStartConsultation = () => {
    setCurrentView('recording');
  };

  const handleCloseRecording = () => {
    setCurrentView('dashboard');
  };

  return (
    <>
      {currentView === 'landing' && <LandingPage onGetStarted={handleGetStarted} />}
      {currentView === 'dashboard' && <Dashboard onStartConsultation={handleStartConsultation} />}
      {currentView === 'recording' && <RecordingInterface onClose={handleCloseRecording} />}
    </>
  );
}

export default App;
