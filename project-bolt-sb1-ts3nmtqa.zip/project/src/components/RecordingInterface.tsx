import { useState, useEffect } from 'react';
import { Mic, MicOff, Save, AlertCircle, Calendar, Pill, FileText, X } from 'lucide-react';
import WaveformAnimation from './WaveformAnimation';
import SOAPNoteEditor from './SOAPNoteEditor';
import { supabase } from '../lib/supabase';

interface RecordingInterfaceProps {
  onClose: () => void;
}

interface SOAPNote {
  subjective: string;
  objective: string;
  assessment: string;
  plan: string;
  chiefComplaint: string;
  medications: string[];
  followUpDate: string;
}

export default function RecordingInterface({ onClose }: RecordingInterfaceProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [patientName, setPatientName] = useState('');
  const [patientMRN, setPatientMRN] = useState('');
  const [showSOAPNote, setShowSOAPNote] = useState(false);
  const [soapNote, setSOAPNote] = useState<SOAPNote | null>(null);
  const [recordingTime, setRecordingTime] = useState(0);

  useEffect(() => {
    let interval: number | undefined;
    if (isRecording) {
      interval = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRecording]);

  const toggleRecording = () => {
    if (!isRecording) {
      if (!patientName || !patientMRN) {
        alert('Please enter patient name and MRN first');
        return;
      }
      setIsRecording(true);
      simulateTranscription();
    } else {
      setIsRecording(false);
      generateSOAPNote();
    }
  };

  const simulateTranscription = () => {
    const sampleTranscript = [
      'Doctor: Good morning! How are you feeling today?',
      'Patient: Namaste Doctor. I have been having pain in my chest since last week.',
      'Doctor: Can you describe the pain? Is it sharp or dull?',
      'Patient: It is a dull ache, mostly on the left side. Sometimes it becomes tez (sharp).',
      'Doctor: Do you have any history of heart disease?',
      'Patient: No Doctor, but my father had heart problems.',
      'Doctor: I see. Any other symptoms like breathlessness or sweating?',
      'Patient: Haan (yes), sometimes I feel thoda breathless when climbing stairs.',
      'Doctor: Let me examine you. Your blood pressure is 140/90, slightly elevated.',
      'Doctor: Heart sounds are normal. Lungs clear.',
      'Patient: Doctor, kya serious hai? (Is it serious?)',
      'Doctor: We need to run an ECG and some blood tests to be sure.',
      'Doctor: I am prescribing aspirin 75mg once daily and ordering tests.',
      'Patient: Theek hai Doctor. When should I come back?',
      'Doctor: Come back next week for follow-up with your test results.'
    ];

    let currentIndex = 0;
    const interval = setInterval(() => {
      if (currentIndex < sampleTranscript.length) {
        setTranscript(prev => prev + (prev ? '\n\n' : '') + sampleTranscript[currentIndex]);
        currentIndex++;
      } else {
        clearInterval(interval);
      }
    }, 2000);
  };

  const generateSOAPNote = () => {
    const note: SOAPNote = {
      subjective: 'Patient reports dull chest pain on the left side for 1 week. Pain occasionally becomes sharp. Patient experiences mild dyspnea on exertion (climbing stairs). Family history positive for cardiac disease (father). No prior history of heart disease.',
      objective: 'BP: 140/90 mmHg (elevated)\nHeart: Regular rate and rhythm, no murmurs\nLungs: Clear to auscultation bilaterally\nNo acute distress observed',
      assessment: 'Chest pain, likely angina pectoris. Rule out acute coronary syndrome. Hypertension, stage 1. Positive family history of cardiovascular disease.',
      plan: '1. ECG ordered\n2. Cardiac biomarkers (Troponin, CK-MB)\n3. Lipid profile\n4. Start Aspirin 75mg PO once daily\n5. Lifestyle modifications counseling\n6. Follow-up in 1 week with test results',
      chiefComplaint: 'Chest pain for 1 week with dyspnea on exertion',
      medications: ['Aspirin 75mg PO once daily'],
      followUpDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    };

    setSOAPNote(note);
    setShowSOAPNote(true);
  };

  const handleSaveNote = async () => {
    if (!soapNote || !patientName || !patientMRN) return;

    let patientId: string | null = null;

    const { data: existingPatient } = await supabase
      .from('patients')
      .select('id')
      .eq('medical_record_number', patientMRN)
      .maybeSingle();

    if (existingPatient) {
      patientId = existingPatient.id;
    } else {
      const { data: newPatient, error: patientError } = await supabase
        .from('patients')
        .insert({
          name: patientName,
          medical_record_number: patientMRN,
        })
        .select()
        .maybeSingle();

      if (patientError) {
        console.error('Error creating patient:', patientError);
        return;
      }

      patientId = newPatient?.id;
    }

    if (!patientId) return;

    const { data: consultation, error: consultationError } = await supabase
      .from('consultations')
      .insert({
        patient_id: patientId,
        physician_name: 'Dr. Smith',
        duration_minutes: Math.floor(recordingTime / 60),
        transcript: transcript,
        status: 'completed'
      })
      .select()
      .maybeSingle();

    if (consultationError) {
      console.error('Error creating consultation:', consultationError);
      return;
    }

    if (!consultation?.id) return;

    const fhirData = {
      resourceType: 'Encounter',
      status: 'finished',
      class: {
        system: 'http://terminology.hl7.org/CodeSystem/v3-ActCode',
        code: 'AMB'
      },
      subject: {
        reference: `Patient/${patientId}`
      }
    };

    await supabase
      .from('soap_notes')
      .insert({
        consultation_id: consultation.id,
        subjective: soapNote.subjective,
        objective: soapNote.objective,
        assessment: soapNote.assessment,
        plan: soapNote.plan,
        chief_complaint: soapNote.chiefComplaint,
        medications: soapNote.medications,
        follow_up_date: soapNote.followUpDate,
        fhir_data: fhirData,
        reviewed_by_physician: false
      });

    onClose();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <nav className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-slate-900">New Consultation</h1>
            <p className="text-sm text-slate-500">Record and transcribe patient consultation</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {!isRecording && !showSOAPNote && (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Patient Information</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Patient Name
                </label>
                <input
                  type="text"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter patient name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Medical Record Number
                </label>
                <input
                  type="text"
                  value={patientMRN}
                  onChange={(e) => setPatientMRN(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter MRN"
                />
              </div>
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
              <div className="text-center mb-6">
                <button
                  onClick={toggleRecording}
                  className={`w-24 h-24 rounded-full flex items-center justify-center transition-all shadow-lg ${
                    isRecording
                      ? 'bg-red-500 hover:bg-red-600 animate-pulse'
                      : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  {isRecording ? (
                    <MicOff className="w-10 h-10 text-white" />
                  ) : (
                    <Mic className="w-10 h-10 text-white" />
                  )}
                </button>
                <p className="mt-4 text-lg font-semibold text-slate-900">
                  {isRecording ? 'Recording...' : 'Click to Start Recording'}
                </p>
                {isRecording && (
                  <p className="text-blue-600 font-mono text-xl mt-2">{formatTime(recordingTime)}</p>
                )}
              </div>

              {isRecording && <WaveformAnimation />}
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center space-x-2">
                <FileText className="w-5 h-5 text-blue-600" />
                <span>Live Transcript</span>
              </h3>
              <div className="bg-slate-50 rounded-lg p-4 h-96 overflow-y-auto border border-slate-200">
                {transcript ? (
                  <p className="text-slate-700 whitespace-pre-wrap font-mono text-sm leading-relaxed">
                    {transcript}
                  </p>
                ) : (
                  <p className="text-slate-400 text-center mt-20">
                    Transcript will appear here when recording starts...
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {showSOAPNote && soapNote ? (
              <>
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                  <div className="flex items-start space-x-3">
                    <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-amber-900 text-sm">Safety Review Required</p>
                      <p className="text-amber-700 text-xs mt-1">
                        AI-generated draft. Physician review required before saving.
                      </p>
                    </div>
                  </div>
                </div>

                <SOAPNoteEditor soapNote={soapNote} onChange={setSOAPNote} />

                <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                  <h3 className="text-lg font-semibold text-slate-900 mb-4">Clinical Intelligence</h3>

                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center space-x-2 mb-2">
                        <AlertCircle className="w-4 h-4 text-blue-600" />
                        <p className="text-sm font-medium text-slate-700">Chief Complaint</p>
                      </div>
                      <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                        {soapNote.chiefComplaint}
                      </p>
                    </div>

                    <div>
                      <div className="flex items-center space-x-2 mb-2">
                        <Pill className="w-4 h-4 text-blue-600" />
                        <p className="text-sm font-medium text-slate-700">Medications</p>
                      </div>
                      <ul className="space-y-1">
                        {soapNote.medications.map((med, idx) => (
                          <li key={idx} className="text-sm text-slate-600 bg-slate-50 p-2 rounded">
                            {med}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <div className="flex items-center space-x-2 mb-2">
                        <Calendar className="w-4 h-4 text-blue-600" />
                        <p className="text-sm font-medium text-slate-700">Follow-up Date</p>
                      </div>
                      <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg">
                        {new Date(soapNote.followUpDate).toLocaleDateString('en-US', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleSaveNote}
                  className="w-full px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-sm inline-flex items-center justify-center space-x-2"
                >
                  <Save className="w-5 h-5" />
                  <span>Save SOAP Note</span>
                </button>
              </>
            ) : (
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">SOAP Note</h3>
                <p className="text-slate-400 text-center py-12">
                  SOAP note will be generated after recording
                </p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
