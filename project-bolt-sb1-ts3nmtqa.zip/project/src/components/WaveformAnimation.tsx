import { useEffect, useState } from 'react';

export default function WaveformAnimation() {
  const [bars, setBars] = useState<number[]>(Array(40).fill(20));

  useEffect(() => {
    const interval = setInterval(() => {
      setBars(prev => prev.map(() => Math.random() * 60 + 20));
    }, 100);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-center justify-center space-x-1 h-24 bg-slate-50 rounded-lg">
      {bars.map((height, index) => (
        <div
          key={index}
          className="w-1 bg-blue-500 rounded-full transition-all duration-100"
          style={{ height: `${height}%` }}
        />
      ))}
    </div>
  );
}
