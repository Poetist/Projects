import { useState, useEffect } from 'react';
import { Plus, User, Calendar, Clock, TrendingUp, Pill } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Consultation {
  id: string;
  patient_name: string;
  physician_name: string;
  consultation_date: string;
  duration_minutes: number;
  soap_notes: {
    medications: string[];
  } | null;
}

interface DashboardProps {
  onStartConsultation: () => void;
}

export default function Dashboard({ onStartConsultation }: DashboardProps) {
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [stats, setStats] = useState({
    timeSavedToday: 45,
    notesCompleted: 12
  });

  useEffect(() => {
    loadConsultations();
  }, []);

  const loadConsultations = async () => {
    const { data, error } = await supabase
      .from('consultations')
      .select(`
        id,
        patient_id,
        physician_name,
        consultation_date,
        duration_minutes,
        patients(name),
        soap_notes(medications)
      `)
      .order('consultation_date', { ascending: false })
      .limit(10);

    if (error) {
      console.error('Error loading consultations:', error);
      return;
    }

    if (data) {
      const formattedConsultations = data.map((consultation: any) => ({
        id: consultation.id,
        patient_name: consultation.patients?.name || 'Unknown Patient',
        physician_name: consultation.physician_name,
        consultation_date: consultation.consultation_date,
        duration_minutes: consultation.duration_minutes,
        soap_notes: consultation.soap_notes?.[0] || null
      }));
      setConsultations(formattedConsultations);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatDay = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long'
    });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <nav className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">SF</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">ScribeFlow AI</h1>
              <p className="text-sm text-slate-500">Clinical Documentation</p>
            </div>
          </div>
          <button
            onClick={onStartConsultation}
            className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-sm inline-flex items-center space-x-2"
          >
            <Plus className="w-5 h-5" />
            <span>Start Consultation</span>
          </button>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Welcome back, Dr. Smith</h2>
          <p className="text-slate-600">Your clinical documentation assistant is ready.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6" />
              </div>
              <TrendingUp className="w-5 h-5 text-blue-200" />
            </div>
            <p className="text-blue-100 text-sm mb-1">Time Saved Today</p>
            <p className="text-4xl font-bold">{stats.timeSavedToday} mins</p>
          </div>

          <div className="bg-gradient-to-br from-slate-700 to-slate-800 rounded-xl p-6 text-white shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6" />
              </div>
              <Calendar className="w-5 h-5 text-slate-400" />
            </div>
            <p className="text-slate-300 text-sm mb-1">Notes Completed</p>
            <p className="text-4xl font-bold">{stats.notesCompleted}</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200">
          <div className="px-6 py-4 border-b border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900">Consultation Records</h3>
          </div>

          {consultations.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500 mb-4">No consultations yet</p>
              <button
                onClick={onStartConsultation}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Start Your First Consultation
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {consultations.map((consultation) => (
                <div
                  key={consultation.id}
                  className="px-6 py-4 hover:bg-slate-50 transition-colors"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                          <User className="w-6 h-6 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-semibold text-slate-900 text-lg">{consultation.patient_name}</p>
                          <p className="text-sm text-slate-500">Dr. {consultation.physician_name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-slate-900">{formatDate(consultation.consultation_date)}</p>
                        <p className="text-xs text-slate-500">{formatDay(consultation.consultation_date)}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 pt-2">
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 text-slate-400" />
                        <div>
                          <p className="text-xs text-slate-500">Timing</p>
                          <p className="text-sm font-medium text-slate-900">{formatTime(consultation.consultation_date)}</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-slate-400" />
                        <div>
                          <p className="text-xs text-slate-500">Duration</p>
                          <p className="text-sm font-medium text-slate-900">{consultation.duration_minutes} mins</p>
                        </div>
                      </div>

                      <div className="flex items-start space-x-2">
                        <Pill className="w-4 h-4 text-slate-400 mt-0.5" />
                        <div>
                          <p className="text-xs text-slate-500">Prescriptions</p>
                          {consultation.soap_notes?.medications && consultation.soap_notes.medications.length > 0 ? (
                            <ul className="text-xs text-slate-900 space-y-0.5">
                              {consultation.soap_notes.medications.slice(0, 2).map((med, idx) => (
                                <li key={idx}>• {med}</li>
                              ))}
                              {consultation.soap_notes.medications.length > 2 && (
                                <li>+{consultation.soap_notes.medications.length - 2} more</li>
                              )}
                            </ul>
                          ) : (
                            <p className="text-xs text-slate-600">No prescriptions</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
