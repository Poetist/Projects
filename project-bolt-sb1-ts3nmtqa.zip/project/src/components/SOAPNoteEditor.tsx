import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface SOAPNote {
  subjective: string;
  objective: string;
  assessment: string;
  plan: string;
  chiefComplaint: string;
  medications: string[];
  followUpDate: string;
}

interface SOAPNoteEditorProps {
  soapNote: SOAPNote;
  onChange: (note: SOAPNote) => void;
}

export default function SOAPNoteEditor({ soapNote, onChange }: SOAPNoteEditorProps) {
  const [expandedSections, setExpandedSections] = useState({
    subjective: true,
    objective: true,
    assessment: true,
    plan: true
  });

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const updateField = (field: keyof SOAPNote, value: string) => {
    onChange({
      ...soapNote,
      [field]: value
    });
  };

  const sections = [
    { key: 'subjective' as const, label: 'Subjective', color: 'blue' },
    { key: 'objective' as const, label: 'Objective', color: 'green' },
    { key: 'assessment' as const, label: 'Assessment', color: 'amber' },
    { key: 'plan' as const, label: 'Plan', color: 'purple' }
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="bg-slate-100 px-6 py-3 border-b border-slate-200">
        <h3 className="text-lg font-semibold text-slate-900">Generated SOAP Note</h3>
      </div>

      <div className="divide-y divide-slate-200">
        {sections.map(({ key, label, color }) => (
          <div key={key}>
            <button
              onClick={() => toggleSection(key)}
              className="w-full px-6 py-3 flex items-center justify-between hover:bg-slate-50 transition-colors"
            >
              <span className="font-semibold text-slate-900">{label}</span>
              {expandedSections[key] ? (
                <ChevronUp className="w-5 h-5 text-slate-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-slate-400" />
              )}
            </button>
            {expandedSections[key] && (
              <div className="px-6 pb-4">
                <textarea
                  value={soapNote[key]}
                  onChange={(e) => updateField(key, e.target.value)}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-sm"
                  rows={4}
                  placeholder={`Enter ${label.toLowerCase()} information...`}
                />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
